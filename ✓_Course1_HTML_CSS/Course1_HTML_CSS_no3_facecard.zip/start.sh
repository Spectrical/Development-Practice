browser-sync start --server . --host 0.0.0.0 --port 6700 --files "**/*"
